<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Muntinlupa City|Home</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <nav>
      <div class="menu">
        <div class="logo">
          <a href="#">Welcome to Muntinlupa City</a>
        </div>
        <ul>
          <li href="#">Home</li>
          <li><a href="news.php" target="main page">News</a><br><br>
          <li><a href="about us.php" target="main page">About Us</a><br><br>
          <li><a href="contact us.php" target="main page">Contact Us</a><br><br>
      </div>
    </nav>
  </body>
</html>
