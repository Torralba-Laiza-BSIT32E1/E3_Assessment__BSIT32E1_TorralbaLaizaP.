<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Muntinlupa City|Home</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <nav>
      <div class="menu">
        <div class="logo">
          <a href="#">Muntinlupa City</a>
        </div>
        <ul>
          <li><a href="./home.php">Home</li>
          <li><a href="./news.php">News</a></li>
          <li><a href="./sports.php">Sports</a></li>
          <li><a href="./entertaining.php">Entertainment</a></li>
          <li><a href="./weather.php">Weather</a></li>
          <li  href="#">Business</a></li>
          <li><a href="./about us.php">About Us</li>
          <li><a href="./contact us">Contact Us</a></li>
        </ul>
      </div>
    </nav>
  </body>
</html>