<!DOCTYPE html>
<html>
    <body style="background-color: yellow;">
    <h1 style="padding-top: 50px; padding-bottom: 15px; font-size: 50; text-align: center;">Categories</h1>
    <center><a href="news.php" target="main page">News</a><br><br></center>
    <center><a href="" target="main page">Sports</a><br><br></center>
    <center><a href="" target="main page">Entertaining</a><br><br></center>
    <center><a href="" target="main page">Weather</a><br><br></center>
    <center><a href="" target="main page">Business</a><br><br></center>
   
   
</html>